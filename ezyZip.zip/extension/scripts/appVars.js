var app_isPRO = "false";
var app_isLogin = "false";
var app_browser = ""; // safari / firefox / chrome / edge / whale
var app_device = ""; // laptop / phone
var app_language = "en";
